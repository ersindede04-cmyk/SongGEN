# SONGDNA Studio 1.7 — QA Report

## Scope and changes
1.7 is based on the supplied 1.6 source package. Existing features/backend are retained.
1. Turkish interface remains Turkish.
2. Selected lyric language is preserved; AI prompt forbids translating/replacing lyric text.
3. Suno section labels and technical cues are specified as English square-bracket tags.
4. Conservative normalizer converts recognized standalone Turkish bracket tags; unknown tags and ordinary lyric lines are preserved.
5. Added Turkish Command Audit output.
6. Pre-Intro uses an English section tag and technical cue.
7. Android versionName 1.7 / versionCode 6; backend remains 1.6.0.

## Preserved capabilities
18 Music DNA presets; fusion, energy, language and BPM; cultural Pre-Intro; lead/backing vocals; ad-libs; vocal effects; OpenAI/Gemini backend; STYLE, EXCLUDE, LYRICS, lyric prompt and vocal brief; local archive, copy/share and Suno launch.

## Known limitations
- Normalizer only converts recognized standalone bracket-tag lines.
- Unknown tags are intentionally preserved rather than guessed.
- English labels do not guarantee Suno's exact performance.
- Command Audit checks text formatting, not Suno's internal interpretation or generated audio.

## Verification status
ZIP integrity, JavaScript syntax, web/Android asset parity and targeted normalization tests are checked during packaging. Real-browser interaction, APK build/install, Android device behavior and live OpenAI/Gemini calls are not verified here. This is a source-package release candidate, not a verified production APK.


## Intro DNA expansion
- Added preset data 14–33 and a selector independent of the main Music DNA selection.
- Existing regional auto-pre-intro behavior remains available as the default "regional auto" option; "Intro yok" is explicit.
- Added Iran and Greece to the regional list.
- English `[Pre-Intro]`, lead-vocal and group-response tags are used in the curated LYRICS templates. Instrumental descriptions and preserve directions are sent through STYLE.
- PRESERVE options: short default, off, long.
- The exact curated vocal text is passed into the AI lyric prompt and is requested unchanged; for pasted lyrics, it is prepended only when no `[Pre-Intro]` is already present.
- Added a Command Audit note when a pasted lyric already contains its own pre-intro and therefore takes precedence over the selected preset.

## Cultural verification caveat
The 14–33 descriptions and vocables are creative draft representations based on the supplied proposal. They have not been validated by native speakers or through controlled Suno audio tests. Region-wide labels (especially Balkan, Andean, Chinese folk and Japanese min'yō) remain broad and should be treated as style inspiration rather than definitive traditional transcriptions.

**Legacy source limitation:** The supplied 1.7 ZIP contains no 13 individually defined intro records/templates. The existing region-based auto-intro path was retained without inventing missing original texts. Add the original 1–13 templates verbatim if provided.
