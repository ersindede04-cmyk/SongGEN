# SONGDNA Studio — Intro DNA 14–33

All new tags are English square-bracket commands. Vocal syllables remain in LYRICS. Instrumental and production directions are routed to STYLE. The main application UI remains Turkish.

| No. | Family | Intro |
|---:|---|---|
| 14 | Pencap | Punjabi Bhangra Call |
| 15 | Pencap | Punjabi Folk Long Phrase |
| 16 | Bengal | Bengali River Call · Bhatiali |
| 17 | Flamenko | Flamenco Cante Opening |
| 18 | Flamenko | Flamenco Jaleo |
| 19 | Balkanlar | Balkan Female Folk Polyphony |
| 20 | Balkanlar | Balkan Dance Call |
| 21 | Latin Amerika | Mariachi Grito |
| 22 | Latin Amerika | Andean Wordless Vocal |
| 23 | Latin Amerika | Afro-Cuban Call & Response |
| 24 | Karayipler | Reggae / Dancehall Call |
| 25 | Karayipler | Soca / Calypso Call |
| 26 | Japonya | Japanese Min'yō Kakegoe |
| 27 | Japonya | Japanese Enka Kobushi |
| 28 | Doğu Asya | Korean Pansori Chuimsae |
| 29 | Doğu Asya | Chinese Folk Pentatonic |
| 30 | Güney Afrika | Zulu Isicathamiya Harmony |
| 31 | Güney Afrika | South African Amapiano Call |
| 32 | İran | Persian Avaz Tahrir |
| 33 | Yunan | Greek Amanes |

## Behavior
- Intro selection is independent of the main Music DNA selection.
- Choices: previous regional automatic intro, no intro, or any preset 14–33.
- PRESERVE: short (default), off, long.
- A selected preset's vocal text is inserted before pasted lyrics only if the pasted lyrics do not already contain `[Pre-Intro]`.
- AI lyric generation receives the exact selected vocal template and is instructed to reproduce it once without translation or rewriting.
- English section and vocal-role labels are used. Instrument descriptions stay in STYLE.
- The selected region is derived from the chosen preset; the regional selector applies to the previous automatic intro flow.

## Cultural validation status
These are draft creative presets based on the supplied proposal, not certified ethnomusicological transcriptions. Regional terms, pronunciations and vocal practices need native-speaker review and repeated Suno audio tests. In particular, broad families such as Balkan, Andean, Chinese folk and Japanese min'yō should not be treated as one uniform tradition.

## Legacy 1–13 source limitation
The supplied 1.7 ZIP did not contain 13 individually defined intro records or their original lyric templates. The previous regional auto-pre-intro behavior is preserved, but the missing numbered templates have not been invented. They can be integrated verbatim when their original source is provided.
