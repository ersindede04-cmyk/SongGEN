# SONGDNA Studio 1.7

SONGDNA Studio is a Turkish-language Android WebView app and mobile web interface for preparing structured, Suno-oriented music prompts and lyric packages.

## 1.7 — Turkish UI / English Suno command layer
- Application interface, labels, controls and help text remain Turkish.
- Actual song lyrics stay in the selected language and are not automatically translated.
- Suno-facing section labels and technical performance cues are requested in English square-bracket tags.
- Recognized Turkish standalone bracket tags are normalized (for example `[Nakarat]` → `[Chorus]`, `[Kıta 1]` → `[Verse 1]`). Ordinary lyric lines and unknown tags are preserved.
- Added a Turkish Command Audit output for tag-language/format review.
- AI lyric prompt explicitly separates lyric language from instruction language.
- Android versionName 1.7 / versionCode 6. Backend remains 1.6.0 because backend code was not changed.

## Preserved from 1.6
- All 18 Music DNA presets; fusion, energy, language and BPM controls.
- Cultural Pre-Intro, lead/backing vocals, ad-libs and vocal effects.
- OpenAI/Gemini lyric generation through private backend; provider keys remain server-side.
- STYLE / EXCLUDE / LYRICS / lyric prompt / vocal brief outputs.
- Local archive, copy, share and Suno launch actions.
- 1.6 Pre-Intro duplication fix, language leakage fixes, backend token lockout and validation.

## Limits
The normalizer only changes recognized standalone bracket-tag lines; it does not translate lyrics or guess unknown tags. English tags improve consistency but cannot guarantee Suno's exact interpretation. The app does not access Suno's private model or source code.

## Backend deployment
Node.js 18+ (Node.js 20 LTS recommended). Configure `backend/.env.example` values as host environment variables: `APP_ACCESS_TOKEN` (12+ chars), `OPENAI_API_KEY` and/or `GEMINI_API_KEY`, optional model settings, `ALLOWED_ORIGIN`, and `TRUST_PROXY` only behind a trusted proxy. Deploy `backend` with HTTPS and verify `/health`. Never put provider API keys in the Android app.

## APK build
GitHub Actions builds a debug APK using Gradle 8.9 and Java 17. Push the repository to GitHub and run **Build APK**; download `SONGDNA-1.7-debug-apk`. This ZIP contains source code, not a prebuilt APK.

See `QA_REPORT_1_7.md` for verification status and limitations.


## Intro DNA expansion (14–33)
- Added 20 curated cultural pre-intro presets (14–33), retaining the existing regional auto-intro flow and the no-intro option.
- Intro selection is independent of the main Music DNA preset. The user may select no intro, the existing regional intro behavior, or any new preset.
- Added Persian and Greek regional choices.
- Each new preset uses English square-bracket section and vocal-role labels. Performable vocal syllables remain in the LYRICS output; instrumental/production directions are routed to STYLE.
- Added PRESERVE modes: off, short (default), and long. Preserve instructions are included in STYLE, not spoken lyric text.
- If user-pasted lyrics already contain a `[Pre-Intro]` section, the app avoids inserting a second intro and reports this in Command Audit.
- The cultural names and vocal phrases are draft creative presets, not independently certified ethnomusicological transcriptions. Validate pronunciation, regional specificity and musical fit with native speakers and repeated Suno generations.

**Source-package note:** The supplied 1.7 ZIP did not contain 13 individually defined intro records or their original lyric templates. The previous regional auto-pre-intro behavior is preserved unchanged; no missing legacy templates have been fabricated. If the original 1–13 source texts are supplied later, they can be added verbatim as selectable presets.
